# INSTRUCTIONS

Press `<` and `>`to change movement speed.
Use `-` and `=` to slow down or speed up time.
Use `WASD` to move back and forward and sides.
Use `IJKL` to pitch and roll.
Use `Q` and `E` to yaw left and right.
Use keys `1-9` to lock at planets.
After selecting a planet with `1-9` use `M` to add moons.
Press `[` and `]` to change the scale of planets. defaults = 500 * realistic scale for visibility. Scale of Sun is limited.
Press `R` to have realistic scale, which will cause invisibility.
Press `O` to toggle the drawing of orbit paths.

1 - Mercury
2 - Venus
3 - Earth
4 - Mars
5 - Jupiter
6 - Saturn
7 - Uranus
8 - Neptune
9 - Pluto
